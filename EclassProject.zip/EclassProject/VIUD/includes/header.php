<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<title>Μάθημα Διαδικτυακός Προγραμματισμός</title>
</head>
<body>
<center>
<img src="icons/header_top.jpg">
</body>