﻿<table class=main_menu>
			<tr>
				<td>
					<a class=menu_a href="index.php">Home</a><font color="#ffffff"><b> | </font>
					<a class=menu_a href="view.php">View</a><font color="#ffffff"><b> | </font>
					<a class=menu_a href="insert.php">Insert</a><font color="#ffffff"><b> | </font>
					<a class=menu_a href="update.php">Update</a><font color="#ffffff"><b> | </font>
					<a class=menu_a href="delete.php">Delete</a><font color="#ffffff"><b></font>
				</td>
			</tr>
</table>