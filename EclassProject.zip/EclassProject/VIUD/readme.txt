V -> View
I -> Insert
U -> Update
D -> Delete